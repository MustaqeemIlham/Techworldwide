<div class="footer">
    

   
        <div class="social">
            <h3>FOLLOW US</h3>
            <a href="https://twitter.com/TechWWide" id="twitter" target="_blank"><i class="fa fa-twitter"></i></a>
            <a href="https://www.facebook.com/profile.php?id=100095252826432&mibextid=LQQJ4d" id="facebook" target="_blank"><i class="fa fa-facebook" target="_blank"></i></a>
            <a href="https://www.instagram.com/techworldwide_0ffcial/" id="insta" target="_blank"><i class="fa fa-instagram"></i></a>

        </div>
        <div class="address">

            <p>Lot P.T 200 Jalan Asam Jawa 16/15 Off <br>
                Persiaran Kemajuan Kuala Terengganu, <br>Terengganu, 40000
                <br><br>(+60) 1355411988 <br>
                techworldwide@gmail.com
            </p>
        </div>
        <p class="copy">Copyright &copy; Techworldwide 2023 original </p>
        <div class="tag">
            <h2>The Platform <br>
                For Legit <br>
                Brands &#174;
            </h2>
        </div>
        <div class="men">
            <h3 id="h3">MENU</h3>
            <a href="index.php">Home</a> <br>
            <a href="productcart.php">Product</a> <br>
            <a href="index.php">Category</a> <br>
            <a href="aboutus.php">About Us</a> <br>
            <a href="feedback.php">Get In Touch</a><br>
        </div>
        
</div>

</body>

</html>